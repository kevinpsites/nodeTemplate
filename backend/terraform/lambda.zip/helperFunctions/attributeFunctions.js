const compareAttributes = (
  attributeDetails,
  previousAssessmentAttributes,
  roundToXSpotsFn
) => {
  const attributeDict = {};

  attributeDetails.items.forEach((ad) => {
    // i.e. faith
    const type = ad.typeID.split("attribute#")[1].split("#")[0];

    // final responseArray of answers
    const finalResponses = [];

    // could be optional/null
    const previousVersionList = previousAssessmentAttributes.items.filter(
      (x) => {
        return x.typeID.includes(type);
      }
    );
    const previousVersion =
      previousVersionList &&
      previousVersionList.length > 0 &&
      previousVersionList[0];

    // calc total percentage diff for entire attribute
    let totalDiff = null;
    if (previousVersion) {
      totalDiff = roundToXSpotsFn(
        ad.json.summary.total.totalPercentage -
          previousVersion.json.summary.total.totalPercentage,
        3
      );
    }
    ad.json.summary.total.totalDiff = totalDiff;

    // capture difference for each individual question/response
    const responseKeys = Object.keys(ad.json.responses);
    responseKeys.forEach((rKey) => {
      const response = ad.json.responses[rKey];
      // "1": {
      //     "rawValue": 1,
      //     "percentage": 0.99
      // },

      let pDiff = null;
      let vDiff = null;

      // go through all current responses if we can compare
      if (previousVersion) {
        const oldResponse = previousVersion.json.responses[rKey];
        pDiff = roundToXSpotsFn(
          response.percentage - oldResponse.percentage,
          3
        );
        vDiff = roundToXSpotsFn(response.rawValue - oldResponse.rawValue, 3);
      }

      finalResponses.push({
        rID: rKey,
        pDiff,
        vDiff,
        ...response,
      });
    });

    if (!attributeDict[type]) {
      attributeDict[type] = {
        type,
        date: ad.createdOn,
        prevDate: previousVersion?.createdOn,
        summary: ad.json.summary,
        responses: finalResponses,
      };
    }
  });

  return attributeDict;
};

module.exports.compareAttributes = compareAttributes;
