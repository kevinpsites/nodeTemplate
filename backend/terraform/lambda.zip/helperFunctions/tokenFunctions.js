const getUserID = (req) => {
  return "auth0|6475234fac6ba292f88d40e6";
  return req.user.token?.sub;
};

module.exports.getUserID = getUserID;
