const createAPI = require("lambda-api");

const config = require("./config");

const responseBuilderFunctions = require("./middleware/responseBuilder");
const { responseBuilder } = responseBuilderFunctions;

const middlewareFunctions = require("./middleware/middlewareFunctions");
const { verifyAuth0TokenMiddleware, verifyRoutePermissionsMiddleware } =
  middlewareFunctions;

const tokenFunctions = require("./helperFunctions/tokenFunctions");
const attributeFunctions = require("./helperFunctions/attributeFunctions");

const validation = require("./services/validation");
const { schemas, validator } = validation;

const basicFunctions = require("./helperFunctions/basicFunctions");
const { BasicFunctions } = basicFunctions;

const dynamodbClass = require("./services/dynamodb");
const { DynamoDBService } = dynamodbClass;

// Routes
const traitResources = require("./routes/traitsRoutes");
const { TraitResources } = traitResources;

const assessmentResources = require("./routes/assessmentRoutes");
const { AssessmentResources } = assessmentResources;

const attributeResources = require("./routes/attributeRoutes");
const { AttributeResources } = attributeResources;

const STAGE_VARIABLE = "/prod";
const routePath = (route, version = "") => {
  return `${STAGE_VARIABLE}${version ? `/${version}` : ""}/${route}`;
};

const createHandler = () => {
  const api = createAPI({
    logger: { level: process.env.LOG_LEVEL || "info" },
  });

  const basicFunctions = new BasicFunctions();
  const dynamoService = new DynamoDBService({ config: config.config });

  const basicResourcesObj = (additionalParams = {}) => {
    return {
      config: config.config,
      basicFunctions,
      dynamoService,
      validatorService: validator,
      schemas: {
        ...schemas,
      },
      tokenFunctions,
      attributeFunctions,
      routePermissionMiddleware: verifyRoutePermissionsMiddleware,
    };
  };

  const newClass = (classType, additionalParams = {}) => {
    const classInstance = new classType(basicResourcesObj(additionalParams));

    return [
      classInstance.routes,
      {
        prefix: routePath(classInstance.prefix),
      },
    ];
  };

  // register response builder helper methods
  api.use(new responseBuilder({ config }).wrapper());

  // Check Token
  // api.use(
  //   [
  //     routePath("search", "v2"),
  //     routePath("thoughts", "v2"),
  //     routePath("threads", "v2"),
  //     routePath("thought", "v2"),
  //     routePath(":threadId/thoughts", "v2"),
  //     routePath(":threadId/thoughts/:thoughtId", "v2"),
  //     routePath("exising/thought", "v2"),
  //   ],
  //   verifyAuth0TokenMiddleware
  // );

  // Register Class Routes
  api.register(...newClass(TraitResources));
  api.register(...newClass(AssessmentResources));
  api.register(...newClass(AttributeResources));

  return async (event, context) => {
    console.log("EVENT", JSON.stringify(event));
    return await api.run(event, context);
  };
};

module.exports.createHandler = createHandler;
