const traits = [
  {
    typeID: "traits#study#study",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "study",
      category: "study",
      scale: {
        highestScore: 5,
        highest: "Almost Always",
        lowest: "Never",
      },
      description:
        "Rate yourself on the following. Review your responses. What are you doing well? Do you wish any of your responses were different? Set one or two goals that will improve the quality of your study.",
      questions: [
        {
          oldID: 6,
          question: "I think about the people I am teaching when I study.",
          scriptureReference: "",
          scripture: "",
          qID: "dfaeb3df-25d7-bc31",
          orderID: 1,
        },
        {
          oldID: 7,
          question:
            "Throughout the day I think about what I studied in the morning.",
          scriptureReference: "",
          scripture: "",
          qID: "84eac404-c59e-7078",
          orderID: 2,
        },
        {
          oldID: 8,
          question:
            "I record spiritual impressions and ideas in an appropriate place.",
          scriptureReference: "",
          scripture: "",
          qID: "56b8e195-fb2d-9bdf",
          orderID: 3,
        },
        {
          oldID: 9,
          question: "I am alert an attentive as I study (not falling asleep)",
          scriptureReference: "",
          scripture: "",
          qID: "4dfc533f-f5f3-32bb",
          orderID: 4,
        },
        {
          oldID: 10,
          question: "I look forward to personal study.",
          scriptureReference: "",
          scripture: "",
          qID: "c014a0e6-89e2-a0ee",
          orderID: 5,
        },
        {
          oldID: 11,
          question: "I look forward to companion study.",
          scriptureReference: "",
          scripture: "",
          qID: "2164f1eb-d9b8-19fc",
          orderID: 6,
        },
      ],
    },
  },
  {
    typeID: "traits#prayer#prayer",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "prayer",
      category: "prayer",
      scale: {
        highestScore: 9,
        highest: "Good",
        lowest: "Poor",
      },
      description:
        "Using the following scale, privately evaluate your prayers. In your study journal, write answers to questions like these: Where would you place yourself on this scale? Where would you like to be on this scale? How are you going to change?\n\n The trouble with most of our prayers is that we give them as if we were picking up the telephone and ordering groceries—we place our order and hang up. We need to meditate, contemplate, think of what we are praying about and for and then speak to the Lord as one man speaketh to another\n\n - Teachings of the Presidents of the Church: Gordon B. Hinckley\n\n If prayer is only a spasmodic cry at the time of crisis, then it is utterly selfish, and we come to think of God as a repairman or a service agency to help us only in our emergencies. We should remember the Most High day and night—always—not only at times when all other assistance has failed and we desperately need help\n\n - Teachings of Presidents of the Church: Howard W. Hunter",
      questions: [
        {
          oldID: 1,
          question: "My prayers show strong faith in Christ",
          scriptureReference: "",
          scripture: "",
          qID: "a13468a7-11a2-f084",
          orderID: 1,
        },
        {
          oldID: 4,
          question: "My prayers are full of thanks",
          scriptureReference: "",
          scripture: "",
          qID: "3a563888-a51d-3470",
          orderID: 2,
        },
        {
          oldID: 5,
          question: "My mind is focused on the work/on what I am doing",
          scriptureReference: "",
          scripture: "",
          qID: "682a95bc-2da7-0bb0",
          orderID: 3,
        },
        {
          oldID: 15,
          question: "My actions fulfill prayers",
          scriptureReference: "",
          scripture: "",
          qID: "6e486cc2-75ba-5b7f",
          orderID: 4,
        },
        {
          oldID: 16,
          question: "My prayers focus on today's needs",
          scriptureReference: "",
          scripture: "",
          qID: "093b080d-6475-38ef",
          orderID: 5,
        },
        {
          oldID: 17,
          question: "My prayers are edifying, refreshing",
          scriptureReference: "",
          scripture: "",
          qID: "ad1e0ce5-9f28-24f0",
          orderID: 6,
        },
        {
          oldID: 18,
          question: "During my prayers I focus on pure thoughts",
          scriptureReference: "",
          scripture: "",
          qID: "55027a7f-abe1-0357",
          orderID: 7,
        },
        {
          oldID: 19,
          question: "My prayers are mindful of other people",
          scriptureReference: "",
          scripture: "",
          qID: "7f68423e-8762-0111",
          orderID: 8,
        },
        {
          oldID: 20,
          question: "My prayers are specific, not general",
          scriptureReference: "",
          scripture: "",
          qID: "57480cd0-cd25-e868",
          orderID: 9,
        },
        {
          oldID: 21,
          question: "The Spirit guides the prayer",
          scriptureReference: "",
          scripture: "",
          qID: "43f4b8c9-1536-fd9c",
          orderID: 10,
        },
        {
          oldID: 22,
          question: "I am confident that God answers prayers",
          scriptureReference: "",
          scripture: "",
          qID: "54d57a1e-4d11-d8a4",
          orderID: 11,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#faith",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "faith",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 24,
          question: "I believe in Christ and accept Him as my Savior.",
          scriptureReference: "2 Nephi 25:29",
          scripture:
            "29 And now behold, I say unto you that the right way is to believe in Christ, and deny him not; and Christ is the Holy One of Israel; wherefore ye must bow down before him, and worship him with all your might, mind, and strength, and your whole soul; and if ye do this ye shall in nowise be cast out.",
          qID: "f07f0c8a-3891-584b",
          orderID: 1,
        },
        {
          oldID: 25,
          question: "I feel confident that God loves me.",
          scriptureReference: "1 Nephi 11:17",
          scripture:
            "17 And I said unto him: I know that he loveth his children; nevertheless, I do not know the meaning of all things.",
          qID: "ed944c2d-89fe-c07d",
          orderID: 2,
        },
        {
          oldID: 26,
          question:
            "I trust the Savior enough to accept His will and do whatever He asks.",
          scriptureReference: "1 Nephi 3:7",
          scripture:
            "7 And it came to pass that I, Nephi, said unto my father: I will go and do the things which the Lord hath commanded, for I know that the Lord giveth no commandments unto the children of men, save he shall prepare a way for them that they may accomplish the thing which he commandeth them.",
          qID: "290ce870-1450-3891",
          orderID: 3,
        },
        {
          oldID: 27,
          question:
            "I firmly believe that through the Atonement of Jesus Christ I can be forgiven of all my sins.",
          scriptureReference: "Enos 1:5–8",
          scripture:
            "<p>5 And there came a voice unto me, saying: Enos, thy sins are forgiven thee, and thou shalt be blessed.\n<br><br>\n6 And I, Enos, knew that God could not lie; wherefore, my guilt was swept away.\n<br><br>\n7 And I said: Lord, how is it done?\n<br><br>\n8 And he said unto me: Because of thy faith in Christ, whom thou hast never before heard nor seen. And many years pass away before he shall manifest himself in the flesh; wherefore, go to, thy faith hath made thee whole.</p>",
          qID: "9ac646db-0008-27b5",
          orderID: 4,
        },
        {
          oldID: 28,
          question:
            "I have enough faith in Christ to obtain answers to my prayers.",
          scriptureReference: "Mosiah 27:14",
          scripture:
            "14 And again, the angel said: Behold, the Lord hath heard the prayers of his people, and also the prayers of his servant, Alma, who is thy father; for he has prayed with much faith concerning thee that thou mightest be brought to the knowledge of the truth; therefore, for this purpose have I come to convince thee of the power and authority of God, that the prayers of his servants might be answered according to their faith.",
          qID: "637f8289-09cf-028f",
          orderID: 5,
        },
        {
          oldID: 29,
          question:
            "I think about the Savior during the day and remember what He has done for me.",
          scriptureReference: "Doctrine and Covenants 20:77, 79",
          scripture:
            "<p>77 O God, the Eternal Father, we ask thee in the name of thy Son, Jesus Christ, to bless and sanctify this bread to the souls of all those who partake of it, that they may eat in remembrance of the body of thy Son, and witness unto thee, O God, the Eternal Father, that they are willing to take upon them the name of thy Son, and always remember him and keep his commandments which he has given them; that they may always have his Spirit to be with them. Amen.\n<br><br>\n79 O God, the Eternal Father, we ask thee in the name of thy Son, Jesus Christ, to bless and sanctify this wine to the souls of all those who drink of it, that they may do it in remembrance of the blood of thy Son, which was shed for them; that they may witness unto thee, O God, the Eternal Father, that they do always remember him, that they may have his Spirit to be with them. Amen.</p>",
          qID: "fe1e134b-93a6-3c2e",
          orderID: 6,
        },
        {
          oldID: 30,
          question:
            "I have the faith necessary to help make good things happen in my life or the lives of others.",
          scriptureReference: "Ether 12:12",
          scripture:
            "12 For if there be no faith among the children of men God can do no miracle among them; wherefore, he showed not himself until after their faith.",
          qID: "52e45a2b-0654-cbea",
          orderID: 7,
        },
        {
          oldID: 31,
          question:
            "I know by the power of the Holy Ghost that the Book of Mormon is true.",
          scriptureReference: "Moroni 10:3–5",
          scripture:
            "<p>3 Behold, I would exhort you that when ye shall read these things, if it be wisdom in God that ye should read them, that ye would remember how merciful the Lord hath been unto the children of men, from the creation of Adam even down until the time that ye shall receive these things, and ponder it in your hearts.\n<br><br>\n4 And when ye shall receive these things, I would exhort you that ye would ask God, the Eternal Father, in the name of Christ, if these things are not true; and if ye shall ask with a sincere heart, with real intent, having faith in Christ, he will manifest the truth of it unto you, by the power of the Holy Ghost.\n<br><br>\n5 And by the power of the Holy Ghost ye may know the truth of all things.</p>",
          qID: "3152c5df-74c6-6409",
          orderID: 8,
        },
        {
          oldID: 32,
          question:
            "I have enough faith in Christ to accomplish anything He wants me to do—even miracles, if necessary.",
          scriptureReference: "Moroni 7:33",
          scripture:
            "33 And Christ hath said: If ye will have faith in me ye shall have power to do whatsoever thing is expedient in me.",
          qID: "936916d6-042a-06ff",
          orderID: 9,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#hope",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "hope",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 33,
          question:
            "One of my greatest desires is to inherit eternal life in the celestial kingdom of God.",
          scriptureReference: "Moroni 7:41",
          scripture:
            "41 And what is it that ye shall hope for? Behold I say unto you that ye shall have hope through the atonement of Christ and the power of his resurrection, to be raised unto life eternal, and this because of your faith in him according to the promise.",
          qID: "ffe6f06a-9f73-adc0",
          orderID: 1,
        },
        {
          oldID: 34,
          question:
            "I am confident that I will have a happy and successful mission (or life).",
          scriptureReference: "Doctrine and Covenants 31:3–5",
          scripture:
            "<p>3 Lift up your heart and rejoice, for the hour of your mission is come; and your tongue shall be loosed, and you shall declare glad tidings of great joy unto this generation.\n<br><br>\n4 You shall declare the things which have been revealed to my servant, Joseph Smith, Jun. You shall begin to preach from this time forth, yea, to reap in the field which is white already to be burned.\n<br><br>\n5 Therefore, thrust in your sickle with all your soul, and your sins are forgiven you, and you shall be laden with sheaves upon your back, for the laborer is worthy of his hire. Wherefore, your family shall live.</p>",
          qID: "7af036de-dec0-8afc",
          orderID: 2,
        },
        {
          oldID: 35,
          question: "I feel peaceful and optimistic about the future.",
          scriptureReference: "Doctrine and Covenants 59:23",
          scripture:
            "23 But learn that he who doeth the works of righteousness shall receive his reward, even peace in this world, and eternal life in the world to come.",
          qID: "9b649377-2a20-f035",
          orderID: 3,
        },
        {
          oldID: 36,
          question:
            "I firmly believe that someday I will dwell with God and become like Him.",
          scriptureReference: "Ether 12:4",
          scripture:
            "4 Wherefore, whoso believeth in God might with surety hope for a better world, yea, even a place at the right hand of God, which hope cometh of faith, maketh an anchor to the souls of men, which would make them sure and steadfast, always abounding in good works, being led to glorify God.",
          qID: "90c55674-f84a-96f0",
          orderID: 4,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#charity",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "charity",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 37,
          question:
            "I feel a sincere desire for the eternal welfare and happiness of other people.",
          scriptureReference: "Mosiah 28:3",
          scripture:
            "3 Now they were desirous that salvation should be declared to every creature, for they could not bear that any human soul should perish; yea, even the very thoughts that any soul should endure endless torment did cause them to quake and tremble.",
          qID: "9106f87b-5858-c38a",
          orderID: 1,
        },
        {
          oldID: 38,
          question: "When I pray, I ask for charity—the pure love of Christ. ",
          scriptureReference: "Moroni 7:47–48",
          scripture:
            "<p>47 But charity is the pure love of Christ, and it endureth forever; and whoso is found possessed of it at the last day, it shall be well with him.\n<br><br>\n48 Wherefore, my beloved brethren, pray unto the Father with all the energy of heart, that ye may be filled with this love, which he hath bestowed upon all who are true followers of his Son, Jesus Christ; that ye may become the sons of God; that when he shall appear we shall be like him, for we shall see him as he is; that we may have this hope; that we may be purified even as he is pure. Amen.</p>",
          qID: "96ed0735-f3e4-e3c5",
          orderID: 2,
        },
        {
          oldID: 39,
          question:
            "I try to understand others’ feelings and see their point of view.",
          scriptureReference: "Jude 1:22",
          scripture: "22 And of some have compassion, making a difference:",
          qID: "df3a21ce-e039-dcef",
          orderID: 3,
        },
        {
          oldID: 40,
          question: "I forgive others who have offended or wronged me. ",
          scriptureReference: "Ephesians 4:32",
          scripture:
            "32 And be ye kind one to another, tenderhearted, forgiving one another, even as God for Christ’s sake hath forgiven you.",
          qID: "940ca611-544d-b079",
          orderID: 4,
        },
        {
          oldID: 41,
          question:
            "I try to help others when they are struggling or discouraged. ",
          scriptureReference: "Mosiah 18:9",
          scripture:
            "9 Yea, and are willing to mourn with those that mourn; yea, and comfort those that stand in need of comfort, and to stand as witnesses of God at all times and in all things, and in all places that ye may be in, even until death, that ye may be redeemed of God, and be numbered with those of the first resurrection, that ye may have eternal life—",
          qID: "a3f78fb7-587e-f6be",
          orderID: 5,
        },
        {
          oldID: 42,
          question:
            "When appropriate, I tell others that I love them and care about them.",
          scriptureReference: "Luke 7:12–15",
          scripture:
            "<p>12 Now when he came nigh to the gate of the city, behold, there was a dead man carried out, the only son of his mother, and she was a widow: and much people of the city was with her.\n<br><br>\n13 And when the Lord saw her, he had compassion on her, and said unto her, Weep not.\n<br><br>\n14 And he came and touched the bier: and they that bare him stood still. And he said, Young man, I say unto thee, Arise.\n<br><br>\n15 And he that was dead sat up, and began to speak. And he delivered him to his mother.<p>",
          qID: "8ae8cdbe-f175-2609",
          orderID: 6,
        },
        {
          oldID: 43,
          question: "I look for opportunities to serve other people.",
          scriptureReference: "Mosiah 2:17",
          scripture:
            "17 And behold, I tell you these things that ye may learn wisdom; that ye may learn that when ye are in the service of your fellow beings ye are only in the service of your God.",
          qID: "c0dc166d-b0a8-2ff4",
          orderID: 7,
        },
        {
          oldID: 44,
          question: "I say positive things about others.",
          scriptureReference: "Doctrine and Covenants 42:27",
          scripture:
            "27 Thou shalt not speak evil of thy neighbor, nor do him any harm.",
          qID: "8ba52c9c-8ac8-206a",
          orderID: 8,
        },
        {
          oldID: 45,
          question:
            "I am kind and patient with others, even when they are hard to get along with.",
          scriptureReference: "Moroni 7:45",
          scripture:
            "45 And charity suffereth long, and is kind, and envieth not, and is not puffed up, seeketh not her own, is not easily provoked, thinketh no evil, and rejoiceth not in iniquity but rejoiceth in the truth, beareth all things, believeth all things, hopeth all things, endureth all things.",
          qID: "a3c8ca2c-ba41-9e5c",
          orderID: 9,
        },
        {
          oldID: 46,
          question: " I find joy in others’ achievements.",
          scriptureReference: "Alma 17:2–4",
          scripture:
            "<p>2 Now these sons of Mosiah were with Alma at the time the angel first appeared unto him; therefore Alma did rejoice exceedingly to see his brethren; and what added more to his joy, they were still his brethren in the Lord; yea, and they had waxed strong in the knowledge of the truth; for they were men of a sound understanding and they had searched the scriptures diligently, that they might know the word of God.\n<br><br>\n3 But this is not all; they had given themselves to much prayer, and fasting; therefore they had the spirit of prophecy, and the spirit of revelation, and when they taught, they taught with power and authority of God.\n<br><br>\n4 And they had been teaching the word of God for the space of fourteen years among the Lamanites, having had much success in bringing many to the knowledge of the truth; yea, by the power of their words many were brought before the altar of God, to call on his name and confess their sins before him.<p>",
          qID: "9289f61a-9966-ca51",
          orderID: 10,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#virtue",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "virtue",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 47,
          question: "I am clean and pure in heart.",
          scriptureReference: "Psalm 24:3–4",
          scripture:
            "<p>3 Who shall ascend into the hill of the Lord? or who shall stand in his holy place?\n<br><br>\n4 He that hath clean hands, and a pure heart; who hath not lifted up his soul unto vanity, nor sworn deceitfully.</p>",
          qID: "a55a2f04-6601-1b06",
          orderID: 1,
        },
        {
          oldID: 48,
          question: "I have no desire to do evil but to do good.",
          scriptureReference: "Mosiah 5:2",
          scripture:
            "2 And they all cried with one voice, saying: Yea, we believe all the words which thou hast spoken unto us; and also, we know of their surety and truth, because of the Spirit of the Lord Omnipotent, which has wrought a mighty change in us, or in our hearts, that we have no more disposition to do evil, but to do good continually.",
          qID: "fd9e0281-36af-843a",
          orderID: 2,
        },
        {
          oldID: 49,
          question: "I am dependable—I do what I say I will do.",
          scriptureReference: "Alma 53:20",
          scripture:
            "20 And they were all young men, and they were exceedingly valiant for courage, and also for strength and activity; but behold, this was not all—they were men who were true at all times in whatsoever thing they were entrusted.",
          qID: "7022071e-de3b-8d41",
          orderID: 3,
        },
        {
          oldID: 50,
          question:
            "I focus on righteous, uplifting thoughts and put unwholesome thoughts out of my mind. ",
          scriptureReference: "Doctrine and Covenants 121:45",
          scripture:
            "45 Let thy bowels also be full of charity towards all men, and to the household of faith, and let virtue garnish thy thoughts unceasingly; then shall thy confidence wax strong in the presence of God; and the doctrine of the priesthood shall distil upon thy soul as the dews from heaven.",
          qID: "b8c69837-bc02-c423",
          orderID: 4,
        },
        {
          oldID: 51,
          question: "I repent of my sins and strive to overcome my weaknesses.",
          scriptureReference: "Doctrine and Covenants 49:26–28",
          scripture:
            "<p>26 Behold, I say unto you, go forth as I have commanded you; repent of all your sins; ask and ye shall receive; knock and it shall be opened unto you.\n<br><br>\n27 Behold, I will go before you and be your rearward; and I will be in your midst, and you shall not be confounded.\n<br><br>\n28 Behold, I am Jesus Christ, and I come quickly. Even so. Amen.</p>",
          qID: "5a3bc1f9-d8ab-8d66",
          orderID: 5,
        },
        {
          oldID: 52,
          question: "I feel the influence of the Holy Ghost in my life.",
          scriptureReference: "Doctrine and Covenants 11:12–13",
          scripture:
            "<p>12 And now, verily, verily, I say unto thee, put your trust in that Spirit which leadeth to do good—yea, to do justly, to walk humbly, to judge righteously; and this is my Spirit.\n<br><br>\n13 Verily, verily, I say unto you, I will impart unto you of my Spirit, which shall enlighten your mind, which shall fill your soul with joy;</p>",
          qID: "1b46a1a8-a604-a876",
          orderID: 6,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#knowledge",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "knowledge",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 53,
          question:
            " I feel confident in my understanding of gospel doctrine and principles.",
          scriptureReference: "Ether 3:19–20",
          scripture:
            "<p>19 And because of the knowledge of this man he could not be kept from beholding within the veil; and he saw the finger of Jesus, which, when he saw, he fell with fear; for he knew that it was the finger of the Lord; and he had faith no longer, for he knew, nothing doubting.\n<br><br>\n20 Wherefore, having this perfect knowledge of God, he could not be kept from within the veil; therefore he saw Jesus; and he did minister unto him.</p>",
          qID: "bc00fe26-0592-ef6c",
          orderID: 1,
        },
        {
          oldID: 54,
          question: "I study the scriptures daily.",
          scriptureReference: "John 5:39",
          scripture:
            "39 ¶ Search the scriptures; for in them ye think ye have eternal life: and they are they which testify of me.",
          qID: "74e60de6-b587-5132",
          orderID: 2,
        },
        {
          oldID: 55,
          question:
            "I earnestly seek to understand the truth and find answers to my questions.",
          scriptureReference: "Doctrine and Covenants 6:7",
          scripture:
            "7 Seek not for riches but for wisdom, and behold, the mysteries of God shall be unfolded unto you, and then shall you be made rich. Behold, he that hath eternal life is rich.",
          qID: "80dedd22-5d1a-ae02",
          orderID: 3,
        },
        {
          oldID: 56,
          question: "I receive knowledge and guidance through the Spirit. ",
          scriptureReference: "1 Nephi 4:6",
          scripture:
            "6 And I was led by the Spirit, not knowing beforehand the things which I should do.",
          qID: "16fa6cd4-33dc-76cd",
          orderID: 4,
        },
        {
          oldID: 57,
          question:
            "I love and cherish the doctrine and principles of the gospel.",
          scriptureReference: "2 Nephi 4:15",
          scripture:
            "15 And upon these I write the things of my soul, and many of the scriptures which are engraven upon the plates of brass. For my soul delighteth in the scriptures, and my heart pondereth them, and writeth them for the learning and the profit of my children.",
          qID: "02f724a4-0b24-fcc9",
          orderID: 5,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#patience",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "patience",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 58,
          question:
            "I wait patiently for the blessings and promises of the Lord to be fulfilled.",
          scriptureReference: "2 Nephi 10:17",
          scripture:
            "17 For I will fulfil my promises which I have made unto the children of men, that I will do unto them while they are in the flesh—",
          qID: "f30d53d2-405a-c26f",
          orderID: 1,
        },
        {
          oldID: 59,
          question:
            "I am able to wait for things without getting upset or frustrated.",
          scriptureReference: "Romans 8:25",
          scripture:
            "25 But if we hope for that we see not, then do we with patience wait for it.",
          qID: "a4ad8af7-35af-351a",
          orderID: 2,
        },
        {
          oldID: 60,
          question:
            "I am patient and long-suffering with the challenges of being a missionary/disciple of Jesus Christ.",
          scriptureReference: "Alma 17:11",
          scripture:
            "11 And the Lord said unto them also: Go forth among the Lamanites, thy brethren, and establish my word; yet ye shall be patient in long-suffering and afflictions, that ye may show forth good examples unto them in me, and I will make an instrument of thee in my hands unto the salvation of many souls.",
          qID: "390464e0-80f7-fc77",
          orderID: 3,
        },
        {
          oldID: 61,
          question: "I am patient with the faults and weaknesses of others. ",
          scriptureReference: "Romans 15:1",
          scripture:
            "1 We then that are strong ought to bear the infirmities of the weak, and not to please ourselves.",
          qID: "2e8c1ac9-64c3-ffb5",
          orderID: 4,
        },
        {
          oldID: 62,
          question:
            "I am patient with myself and rely on the Lord as I work to overcome my weaknesses.",
          scriptureReference: "Ether 12:27",
          scripture:
            "27 And if men come unto me I will show unto them their weakness. I give unto men weakness that they may be humble; and my grace is sufficient for all men that humble themselves before me; for if they humble themselves before me, and have faith in me, then will I make weak things become strong unto them.",
          qID: "6fb39d64-80c5-84a5",
          orderID: 5,
        },
        {
          oldID: 63,
          question: "I face adversity and afflictions calmly and hopefully. ",
          scriptureReference: "Alma 34:40–41",
          scripture:
            "<p>40 And now my beloved brethren, I would exhort you to have patience, and that ye bear with all manner of afflictions; that ye do not revile against those who do cast you out because of your exceeding poverty, lest ye become sinners like unto them;\n<br><br>\n41 But that ye have patience, and bear with those afflictions, with a firm hope that ye shall one day rest from all your afflictions.</p>",
          qID: "4f78f85f-c11b-3ce1",
          orderID: 6,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#humility",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "humility",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 64,
          question: " I am meek and lowly in heart.",
          scriptureReference: "Matthew 11:29",
          scripture:
            "29 Take my yoke upon you, and learn of me; for I am meek and lowly in heart: and ye shall find rest unto your souls.",
          qID: "4b722f02-3ef6-42d1",
          orderID: 1,
        },
        {
          oldID: 65,
          question: "I rely on the Lord for help.",
          scriptureReference: "Alma 26:12",
          scripture:
            "12 Yea, I know that I am nothing; as to my strength I am weak; therefore I will not boast of myself, but I will boast of my God, for in his strength I can do all things; yea, behold, many mighty miracles we have wrought in this land, for which we will praise his name forever.",
          qID: "69b8386c-37a1-13bb",
          orderID: 2,
        },
        {
          oldID: 66,
          question:
            "I am sincerely grateful for the blessings I have received from the Lord.",
          scriptureReference: "Alma 7:23",
          scripture:
            "23 And now I would that ye should be humble, and be submissive and gentle; easy to be entreated; full of patience and long-suffering; being temperate in all things; being diligent in keeping the commandments of God at all times; asking for whatsoever things ye stand in need, both spiritual and temporal; always returning thanks unto God for whatsoever things ye do receive.",
          qID: "df0e4851-4ecf-76d8",
          orderID: 3,
        },
        {
          oldID: 67,
          question: "My prayers are earnest and sincere.",
          scriptureReference: "Enos 1:4",
          scripture:
            "4 And my soul hungered; and I kneeled down before my Maker, and I cried unto him in mighty prayer and supplication for mine own soul; and all the day long did I cry unto him; yea, and when the night came I did still raise my voice high that it reached the heavens.",
          qID: "1ab7a3d9-bcaa-4d8f",
          orderID: 4,
        },
        {
          oldID: 68,
          question: "I appreciate direction from my leaders or teachers. ",
          scriptureReference: "2 Nephi 9:28",
          scripture:
            "28 O that cunning plan of the evil one! O the vainness, and the frailties, and the foolishness of men! When they are learned they think they are wise, and they hearken not unto the counsel of God, for they set it aside, supposing they know of themselves, wherefore, their wisdom is foolishness and it profiteth them not. And they shall perish.",
          qID: "52d5edb4-5582-d03a",
          orderID: 5,
        },
        {
          oldID: 69,
          question:
            "I strive to be submissive to the Lord’s will, whatever it may be.",
          scriptureReference: "Mosiah 24:15",
          scripture:
            "15 And now it came to pass that the burdens which were laid upon Alma and his brethren were made light; yea, the Lord did strengthen them that they could bear up their burdens with ease, and they did submit cheerfully and with patience to all the will of the Lord.",
          qID: "52b7e377-bdf1-15f7",
          orderID: 6,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#diligence",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "diligence",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 70,
          question:
            "I work effectively, even when I’m not under pressure or close supervision.",
          scriptureReference: "Doctrine and Covenants 58:26–27",
          scripture:
            "<p>26 For behold, it is not meet that I should command in all things; for he that is compelled in all things, the same is a slothful and not a wise servant; wherefore he receiveth no reward.\n<br><br>\n27 Verily I say, men should be anxiously engaged in a good cause, and do many things of their own free will, and bring to pass much righteousness;</p>",
          qID: "e855b68c-ea5a-e42f",
          orderID: 1,
        },
        {
          oldID: 71,
          question: "I focus my efforts on the most important things. ",
          scriptureReference: "Matthew 23:23",
          scripture:
            "23 Woe unto you, scribes and Pharisees, hypocrites! for ye pay tithe of mint and anise and cummin, and have omitted the weightier matters of the law, judgment, mercy, and faith: these ought ye to have done, and not to leave the other undone.",
          qID: "948d5452-43cd-f7ea",
          orderID: 2,
        },
        {
          oldID: 72,
          question: "I have a personal prayer at least twice a day.",
          scriptureReference: "Alma 34:18–27",
          scripture:
            "<p>18 Yea, cry unto him for mercy; for he is mighty to save.\n<br><br>\n19 Yea, humble yourselves, and continue in prayer unto him.\n<br><br>\n20 Cry unto him when ye are in your fields, yea, over all your flocks.\n<br><br>\n21 Cry unto him in your houses, yea, over all your household, both morning, mid-day, and evening.\n<br><br>\n22 Yea, cry unto him against the power of your enemies.\n<br><br>\n23 Yea, cry unto him against the devil, who is an enemy to all righteousness.\n<br><br>\n24 Cry unto him over the crops of your fields, that ye may prosper in them.\n<br><br>\n25 Cry over the flocks of your fields, that they may increase.\n<br><br>\n26 But this is not all; ye must pour out your souls in your closets, and your secret places, and in your wilderness.\n<br><br>\n27 Yea, and when you do not cry unto the Lord, let your hearts be full, drawn out in prayer unto him continually for your welfare, and also for the welfare of those who are around you.<p>",
          qID: "84e1f8a9-7fb8-161f",
          orderID: 3,
        },
        {
          oldID: 73,
          question:
            "I focus my thoughts on my calling as a missionary/on being a disciple of Jesus Christ.",
          scriptureReference: "Doctrine and Covenants 4:2, 5",
          scripture:
            "<p>2 Therefore, O ye that embark in the service of God, see that ye serve him with all your heart, might, mind and strength, that ye may stand blameless before God at the last day.\n<br><br>\n5 And faith, hope, charity and love, with an eye single to the glory of God, qualify him for the work.</p>",
          qID: "15c9208b-6256-df83",
          orderID: 4,
        },
        {
          oldID: 74,
          question: "I set goals and plan regularly.",
          scriptureReference: "Doctrine and Covenants 88:119",
          scripture:
            "119 Organize yourselves; prepare every needful thing; and establish a house, even a house of prayer, a house of fasting, a house of faith, a house of learning, a house of glory, a house of order, a house of God;",
          qID: "bec43a5d-524d-4399",
          orderID: 5,
        },
        {
          oldID: 75,
          question: "I work hard until the job is completed successfully. ",
          scriptureReference: "Doctrine and Covenants 10:4",
          scripture:
            "4 Do not run faster or labor more than you have strength and means provided to enable you to translate; but be diligent unto the end.",
          qID: "05ad776a-a60d-fcd9",
          orderID: 6,
        },
        {
          oldID: 76,
          question: "I find joy and satisfaction in my work.",
          scriptureReference: "Alma 36:24–25",
          scripture:
            "<p>24 Yea, and from that time even until now, I have labored without ceasing, that I might bring souls unto repentance; that I might bring them to taste of the exceeding joy of which I did taste; that they might also be born of God, and be filled with the Holy Ghost.\n<br><br>\n25 Yea, and now behold, O my son, the Lord doth give me exceedingly great joy in the fruit of my labors;</p>",
          qID: "a6aa042f-3ad1-7d5b",
          orderID: 7,
        },
      ],
    },
  },
  {
    typeID: "traits#christlike#obedience",
    assessmentID: "traits",
    userID: "main_traits",
    createdOn: 1698008594612,
    json: {
      type: "obedience",
      category: "christlike",
      scale: {
        highestScore: 5,
        highest: "Always",
        lowest: "Never",
      },
      description: "",
      questions: [
        {
          oldID: 77,
          question:
            "When I pray, I ask for strength to resist temptation and to do what is right. ",
          scriptureReference: "3 Nephi 18:15",
          scripture:
            "15 Verily, verily, I say unto you, ye must watch and pray always, lest ye be tempted by the devil, and ye be led away captive by him.",
          qID: "11a894ea-71ed-77e2",
          orderID: 1,
        },
        {
          oldID: 78,
          question:
            "I keep the required commandments to be worthy of a temple recommend.",
          scriptureReference: "Doctrine and Covenants 97:8",
          scripture:
            "8 Verily I say unto you, all among them who know their hearts are honest, and are broken, and their spirits contrite, and are willing to observe their covenants by sacrifice—yea, every sacrifice which I, the Lord, shall command—they are accepted of me.",
          qID: "9cda531b-5172-c874",
          orderID: 2,
        },
        {
          oldID: 79,
          question:
            "I willingly obey the mission rules and follow the counsel of my leaders. ",
          scriptureReference: "Hebrews 13:17",
          scripture:
            "17 Obey them that have the rule over you, and submit yourselves: for they watch for your souls, as they that must give account, that they may do it with joy, and not with grief: for that is unprofitable for you.",
          qID: "9580b126-65a1-a5b5",
          orderID: 3,
        },
        {
          oldID: 80,
          question:
            "I strive to live in accordance with the laws and principles of the gospel.",
          scriptureReference: "Doctrine and Covenants 41:5",
          scripture:
            "5 He that receiveth my law and doeth it, the same is my disciple; and he that saith he receiveth it and doeth it not, the same is not my disciple, and shall be cast out from among you;",
          qID: "f22c61b3-2483-e31f",
          orderID: 4,
        },
      ],
    },
  },
];
