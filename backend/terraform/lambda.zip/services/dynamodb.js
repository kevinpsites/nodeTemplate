const awsDynamo = require("@aws-sdk/lib-dynamodb");
const awsDynamoClient = require("@aws-sdk/client-dynamodb");
const { DynamoDBClient } = awsDynamoClient;

const {
  ScanCommand,
  QueryCommand,
  DeleteCommand,
  PutCommand,
  UpdateCommand,
  GetCommand,
} = awsDynamo;

const awsSettings = {
  region: "us-east-1",
};

const generateThreadId = () => "";

/**
 * Create the {@link DynamoDBDocumentClient} with the given configuration.
 */
function createDynamoDBClient() {
  //   logger.info(`Creating DynamoDBClient for region ${awsSettings.region}`);

  const client = new DynamoDBClient(awsSettings);
  //   return DynamoDBDocumentClient.from(client);

  return client;
}

class DynamoDBService {
  #dynamoDBClient;
  #config;
  constructor({ config }) {
    this.#dynamoDBClient = createDynamoDBClient();

    this.#config = config;
  }

  async send(requestName, command) {
    var status = "success";
    try {
      return await this.#dynamoDBClient.send(command);
    } catch (err) {
      status = "failure";
      throw err;
    } finally {
      console.log("Dynamo Res status: ", status);
    }
  }

  async scanCommand(params) {
    const command = new ScanCommand(params);
    const scanResults = [];
    let items = [];
    do {
      items = await this.send("scan", command);
      items.Items.forEach((item) => scanResults.push(item));
      params.ExclusiveStartKey = items.LastEvaluatedKey;
    } while (typeof items.LastEvaluatedKey !== "undefined");

    return scanResults;
  }

  async queryFirstItem(params, allowEmpty) {
    const command = new QueryCommand(params);

    const queryResponse = await this.send("query", command);
    if (queryResponse.Count === 0 && !allowEmpty) {
      // QUESTION - log here with some identifier?
      throw new Error(`No records found`);
    } else if (queryResponse.Count === 0 && allowEmpty) {
      return null;
    }
    return queryResponse.Items[0];
  }

  async queryItems(params, nextPageKey = false) {
    const command = new QueryCommand(params);

    const queryResponse = await this.send("query", command);
    if (queryResponse.Count === 0) {
      // QUESTION - log here with some identifier?
      throw new Error(`No records found`);
    }

    if (nextPageKey) {
      return [queryResponse.Items, res.LastEvaluatedKey];
    }
    return queryResponse.Items;
  }

  //   async scanAllConfigsFromTrackV2Form() {
  //     var params = {
  //       TableName: this.#config.trackV2FormTable,
  //       ExpressionAttributeNames: {
  //         "#accountId": "account_id",
  //         "#description": "description",
  //         "#formId": "form_id",
  //         "#name": "name",
  //       },
  //       ProjectionExpression: "#formId, #accountId, #description, #name",
  //     };
  //     return await this.scanCommand(params);
  //   }

  async queryAllTraits(nextPageKey = "") {
    let params = {
      TableName: this.#config.mainDynamodbTable,
      // IndexName: "userID_idx",
      KeyConditionExpression: "#pk=:pk",
      ExpressionAttributeNames: {
        "#pk": "assessmentID",
      },
      ExpressionAttributeValues: {
        ":pk": `traits`,
      },
      ScanIndexForward: false, // false = descending, true = ascending
      // Limit: 100,
    };

    // if (nextPageKey) {
    //   params.ExclusiveStartKey = { threadId: nextPageKey };
    // }

    const res = await this.queryItems(params);
    return {
      items: res,
    };
  }

  // GET ALL ASSESMENTS
  async queryAllUserAssessments(userID, nextPageKey = "") {
    let params = {
      TableName: this.#config.mainDynamodbTable,
      IndexName: "userID_idx",
      KeyConditionExpression: "#pk=:pk AND begins_with(#sk, :type)",
      ExpressionAttributeNames: {
        "#pk": "userID",
        "#sk": "typeID",
      },
      ExpressionAttributeValues: {
        ":pk": `${userID}_assessment`,
        ":type": "assessment#",
      },
      ScanIndexForward: false, // false = descending, true = ascending
      // Limit: 100,
    };

    // if (nextPageKey) {
    //   params.ExclusiveStartKey = { threadId: nextPageKey };
    // }

    const res = await this.queryItems(params);
    return {
      items: res,
    };
  }

  // GET ASSESSMENT DETAILS
  // assumptions - userID has been checked for assessment ID previously
  async queryAssessmentDetails(assessmentID, nextPageKey = "") {
    let params = {
      TableName: this.#config.mainDynamodbTable,
      KeyConditionExpression: "#pk=:pk AND begins_with(#sk, :type)",
      ExpressionAttributeNames: {
        "#pk": "assessmentID",
        "#sk": "typeID",
      },
      ExpressionAttributeValues: {
        ":pk": assessmentID,
        ":type": "attribute#",
      },
      ScanIndexForward: false,
      // Limit: 100,
    };

    // if (nextPageKey) {
    //   params.ExclusiveStartKey = { threadId: nextPageKey };
    // }

    const res = await this.queryItems(params);
    return {
      items: res,
    };
  }

  // GET ATTRIBUTE RESULT FROM ALL ASSESSMENTS
  async queryAttributeEntries(userID, attributeName, nextPageKey = "") {
    let params = {
      TableName: this.#config.mainDynamodbTable,
      IndexName: "userID_idx",
      KeyConditionExpression: "#pk=:pk AND begins_with(#sk, :type)",
      ExpressionAttributeNames: {
        "#pk": "userID",
        "#sk": "typeID",
      },
      ExpressionAttributeValues: {
        ":pk": `${userID}_attribute`,
        ":type": `attribute#${attributeName.toLowerCase()}`,
      },
      ScanIndexForward: false,
      // Limit: 100,
    };

    // if (nextPageKey) {
    //   params.ExclusiveStartKey = { threadId: nextPageKey };
    // }

    const res = await this.queryItems(params);
    return {
      items: res,
    };
  }

  async querySingleAssessment(userID, assessmentKey, nextPageKey = "") {
    let params = {
      TableName: this.#config.mainDynamodbTable,
      KeyConditionExpression: "#pk=:pk AND begins_with(#sk, :type)",
      ExpressionAttributeNames: {
        "#pk": "assessmentID",
        "#sk": "typeID",
      },
      ExpressionAttributeValues: {
        ":pk": assessmentKey,
        ":type": `assessment#`,
      },
      ScanIndexForward: false,
      Limit: 1,
    };

    // if (nextPageKey) {
    //   params.ExclusiveStartKey = { threadId: nextPageKey };
    // }

    const res = await this.queryFirstItem(params);

    // TO-DO - Verify userID belongs to this attribute - CHECK
    if (res.userID && !res.userID.includes(userID)) {
      throw new Error(`No records found`);
    }

    return res;
  }

  async queryPreviousAssessmentByDate(
    userID,
    lastAssessmentDate,
    nextPageKey = ""
  ) {
    let params = {
      TableName: this.#config.mainDynamodbTable,
      IndexName: "createdOn_idx",
      KeyConditionExpression: "#pk = :pk AND #sk < :date",
      ExpressionAttributeNames: {
        "#pk": "userID",
        "#sk": "createdOn",
      },
      ExpressionAttributeValues: {
        ":pk": `${userID}_assessment`,
        ":date": lastAssessmentDate,
      },
      ScanIndexForward: false,
      Limit: 1,
    };

    // if (nextPageKey) {
    //   params.ExclusiveStartKey = { threadId: nextPageKey };
    // }

    const res = await this.queryFirstItem(params, true);
    return res;
  }

  // Create New Assessment record
  // Assumptions: Schema Validator has been run
  async createAssessment(item) {
    console.log("PUTTING ITEM", item);
    const command = new PutCommand({
      TableName: this.#config.mainDynamodbTable,
      Item: item,
    });
    return this.send("put", command);
  }

  async updateAssessment({ assessmentID, typeID, complete, testsTaken }) {
    const command = new UpdateCommand({
      TableName: this.#config.mainDynamodbTable,
      Key: {
        assessmentID,
        typeID,
      },
      UpdateExpression: "set modifiedOn = :modifiedOn, json = :json", // For example, "'set Title = :t, Subtitle = :s'"
      ExpressionAttributeValues: {
        ":modifiedOn": Date.now(),
        ":json": {
          complete,
          testsTaken,
        },
      },
      ReturnValues: "ALL_NEW",
    });

    const res = await this.send("update", command);
    return res.Attributes;
  }

  // Create New Assessment record
  // Assumptions: Schema Validator has been run
  async createAttributeDetail(item) {
    console.log("PUTTING ITEM", item);
    const command = new PutCommand({
      TableName: this.#config.mainDynamodbTable,
      Item: item,
    });
    return this.send("put", command);
  }

  //
  //
  // OTHER PROJECT
  async queryAllUserThreads(userId, attributeName) {
    var params = {
      TableName: this.#config.mainDynamodbTable,
      KeyConditionExpression: "#threadId=:threadId",
      ExpressionAttributeNames: {
        "#threadId": "threadId",
      },
      ExpressionAttributeValues: {
        ":threadId": generateThreadId(userId, ""),
      },
    };
    const command = new QueryCommand(params);

    const res = await this.send("query", command);
    return res.Items.sort((a, b) => a.createdOn - b.createdOn);
  }

  async queryAllThreadThoughts(threadId) {
    var params = {
      TableName: this.#config.mainDynamodbTable,
      KeyConditionExpression: "#threadId=:threadId",
      ExpressionAttributeNames: {
        "#threadId": "threadId",
      },
      ExpressionAttributeValues: {
        ":threadId": threadId,
      },
    };
    const command = new QueryCommand(params);

    const res = await this.send("query", command);
    return res.Items;
  }

  async getThought(thoughtId, threadId) {
    var params = {
      TableName: this.#config.mainDynamodbTable,
      Key: {
        threadId,
        thoughtId,
      },
    };
    const command = new GetCommand(params);

    const res = await this.send("get", command);
    return res.Item;
  }

  async createThought(thoughtItem) {
    const command = new PutCommand({
      TableName: this.#config.mainDynamodbTable,
      Item: thoughtItem,
    });
    return this.send("put", command);
  }

  async deleteThought(thoughtId, threadId) {
    const command = new DeleteCommand({
      TableName: this.#config.mainDynamodbTable,
      Key: {
        threadId,
        thoughtId,
      },
    });
    return this.send("delete", command);
  }

  async updateThought({
    thoughtId,
    threadId,
    modifiedOn,
    type,
    thought,
    title,
    tags,
  }) {
    const command = new UpdateCommand({
      TableName: this.#config.mainDynamodbTable,
      Key: {
        threadId,
        thoughtId,
      },
      UpdateExpression:
        "set modifiedOn = :modifiedOn, #thought_type = :type, thought = :thought, title = :title, tags = :tags", // For example, "'set Title = :t, Subtitle = :s'"
      ExpressionAttributeValues: {
        ":modifiedOn": modifiedOn,
        ":type": type,
        ":thought": thought,
        ":title": title,
        ":tags": tags,
      },
      ExpressionAttributeNames: {
        "#thought_type": "type",
      },
      ReturnValues: "ALL_NEW",
    });

    const res = await this.send("update", command);
    return res.Attributes;
  }
}

module.exports.DynamoDBService = DynamoDBService;
