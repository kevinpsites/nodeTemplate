var Validator = require("jsonschema").Validator;
var validate = new Validator();

const attributeSchemas = require("../schemas/attributeSchemas");

// example
const exampleSchema = {
  id: "/item",
  type: "object",
  properties: {
    hashId: { type: "string" },
    rangeId: { type: "string" },
    userId: { type: "string" },
    createdOn: { type: "integer" },
    modifiedOn: { type: "integer" },
    tags: { type: "array" },
  },
  required: ["hashId", "rangeId", "userId"],
};

// console.log(v.validate(p, schema));
module.exports.exampleSchema = exampleSchema;
module.exports.validator = validate;

const assessmentSchema = {
  id: "/assessment",
  type: "object",
  properties: {
    typeID: { type: "string" },
    assessmentID: { type: "string" },
    userID: { type: "string" },
    createdOn: { type: "integer" },
    modifiedOn: { type: "integer" },

    json: {
      type: "object",
      properties: {
        complete: {
          type: "boolean",
        },
        testsTaken: {
          type: "array",
          items: {
            type: "string",
            enum: attributeSchemas.attributeTypes,
          },
        },
      },
      required: ["complete", "testsTaken"],
      additionalProperties: false,
    },
  },
  required: [
    "typeID",
    "assessmentID",
    "userID",
    "createdOn",
    "modifiedOn",
    "json",
  ],
  additionalProperties: false,
};

module.exports.schemas = {
  assessmentSchema,

  attributeTypes: attributeSchemas.attributeTypes,

  ...attributeSchemas.schemas,
};
