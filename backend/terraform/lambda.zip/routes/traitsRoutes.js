class TraitResources {
  prefix = "traits";

  #config;
  #basicFunctions;
  #dynamoService;
  #tokenFunctions;
  #routePermissionMiddleware;
  #validatorService;
  #schemas;

  constructor({
    config,
    basicFunctions,
    dynamoService,
    tokenFunctions,
    routePermissionMiddleware,
    validatorService,
    schemas,
  }) {
    this.#config = config;
    this.#basicFunctions = basicFunctions;
    this.#dynamoService = dynamoService;
    this.#tokenFunctions = tokenFunctions;
    this.#routePermissionMiddleware = routePermissionMiddleware;
    this.#validatorService = validatorService;
    this.#schemas = schemas;
  }

  routes = (api, opts) => {
    api.get(
      "/",
      //   verifyRoutePermissionsMiddleware("read:thoughts"),
      async (req, res) => {
        const traits = await this.#dynamoService.queryAllTraits();

        return res.success({
          traits: traits.items,
        });
      }
    );

    // sample traits

    // {
    //   traits:[
    //     {
    //       "typeID": "traits#study#study",
    //       "createdOn": 1698008594612,
    //       "modifiedOn": 1698008594612,
    //       "userID": "main_traits",
    //       "json": {
    //           "questions": [
    //               {
    //                   "scripture": "",
    //                   "oldID": 6,
    //                   "question": "I think about the people I am teaching when I study.",
    //                   "scriptureReference": "",
    //                   "qID": "dfaeb3df-25d7-bc31",
    //                   "orderID": 1
    //               },
    //               {
    //                   "scripture": "",
    //                   "oldID": 7,
    //                   "question": "Throughout the day I think about what I studied in the morning.",
    //                   "scriptureReference": "",
    //                   "qID": "84eac404-c59e-7078",
    //                   "orderID": 2
    //               },
    //               {
    //                   "scripture": "",
    //                   "oldID": 8,
    //                   "question": "I record spiritual impressions and ideas in an appropriate place.",
    //                   "scriptureReference": "",
    //                   "qID": "56b8e195-fb2d-9bdf",
    //                   "orderID": 3
    //               },
    //               {
    //                   "scripture": "",
    //                   "oldID": 9,
    //                   "question": "I am alert an attentive as I study (not falling asleep)",
    //                   "scriptureReference": "",
    //                   "qID": "4dfc533f-f5f3-32bb",
    //                   "orderID": 4
    //               },
    //               {
    //                   "scripture": "",
    //                   "oldID": 10,
    //                   "question": "I look forward to personal study.",
    //                   "scriptureReference": "",
    //                   "qID": "c014a0e6-89e2-a0ee",
    //                   "orderID": 5
    //               },
    //               {
    //                   "scripture": "",
    //                   "oldID": 11,
    //                   "question": "I look forward to companion study.",
    //                   "scriptureReference": "",
    //                   "qID": "2164f1eb-d9b8-19fc",
    //                   "orderID": 6
    //               }
    //           ],
    //           "scale": {
    //               "highestScore": 5,
    //               "highest": "Almost Always",
    //               "lowest": "Never"
    //           },
    //           "description": "Rate yourself on the following. Review your responses. What are you doing well? Do you wish any of your responses were different? Set one or two goals that will improve the quality of your study.",
    //           "type": "study",
    //           "category": "study"
    //       },
    //       "assessmentID": "traits"
    //   },
    //   ]
    // }
  };
}

module.exports.TraitResources = TraitResources;
