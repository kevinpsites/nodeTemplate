class AttributeResources {
  prefix = "attribute";

  #config;
  #basicFunctions;
  #dynamoService;
  #tokenFunctions;
  #routePermissionMiddleware;
  #validatorService;
  #schemas;

  constructor({
    config,
    basicFunctions,
    dynamoService,
    tokenFunctions,
    routePermissionMiddleware,
    validatorService,
    schemas,
  }) {
    this.#config = config;
    this.#basicFunctions = basicFunctions;
    this.#dynamoService = dynamoService;
    this.#tokenFunctions = tokenFunctions;
    this.#routePermissionMiddleware = routePermissionMiddleware;
    this.#validatorService = validatorService;
    this.#schemas = schemas;
  }

  routes = (api, opts) => {
    api.post(
      "/:assessmentID/:attributeType",
      //   verifyRoutePermissionsMiddleware("read:thoughts"),
      async (req, res) => {
        const userID = this.#tokenFunctions.getUserID(req);

        const body = req.body ?? {};
        // const { attributeType: attributeTypeQ, assessmentID: assessmentIDQ } =
        //   req.query ?? {};
        const { attributeType: attributeTypeQ, assessmentID: assessmentIDQ } =
          req.pathParameters ?? {};

        const attributeType = attributeTypeQ.toLowerCase();

        // validate attribute type
        const validType = this.#validatorService.validate(
          { attributeType },
          this.#schemas.attributeTypeSchema
        );
        if (!validType.valid) {
          return res.success(
            {
              error: validType.errors[0],
            },
            "Invalid Attribute"
          );
        }

        const attributeSchema = this.#schemas.getAttributeSchema(attributeType);

        // validate Body info
        const validBody = this.#validatorService.validate(
          body,
          attributeSchema
        );
        if (!validBody.valid) {
          return res.success(
            {
              error: validBody.errors[0],
            },
            "Schema Failed"
          );
        }

        const { assessmentID, typeID, json } =
          await this.#dynamoService.querySingleAssessment(
            userID,
            assessmentIDQ
          );

        // validate that attribute hasn't already been used
        if (json.testsTaken?.includes(attributeType)) {
          return res.failure({ error: "Trait Already Taken" });
        }

        if (json.complete) {
          return res.failure({ error: "Assessment is Complete" });
        }

        let highest = { id: 0, score: 0 };
        let lowest = { id: 0, score: 1 };
        let total = { questionCount: 0, totalPercentage: 0 };
        for (let ki = 0; ki < body.length; ki++) {
          const response = body[ki];

          if (response.percentage < lowest.score) {
            lowest = {
              id: response.qID,
              score: response.percentage,
            };
          }

          if (response.percentage > highest.score) {
            highest = {
              id: response.qID,
              score: response.percentage,
            };
          }

          total.questionCount += 1;
          total.totalPercentage += response.percentage;
        }

        total.totalPercentage = this.#basicFunctions.roundToXSpots(
          total.totalPercentage / total.questionCount,
          3
        );

        const storedDate = Date.now();
        const newAttributeDetail = {
          typeID: `attribute#${attributeType}#${assessmentID}`,
          assessmentID,
          userID: `${userID}_attribute`,
          createdOn: storedDate,
          modifiedOn: storedDate,
          json: {
            responses: body,
            summary: {
              highest,
              lowest,
              total,
            },
          },
        };

        const validObj = this.#validatorService.validate(
          newAttributeDetail,
          this.#schemas.attributeDetailSchema
        );
        if (!validObj.valid) {
          return res.success(
            {
              error: validObj.errors[0],
            },
            "Schema Failed"
          );
        }

        // create new attribute detail
        const dynamoRes = await this.#dynamoService.createAttributeDetail(
          newAttributeDetail
        );

        // update assessemnt
        json.testsTaken?.push(attributeType);

        // if complete
        if (json.testsTaken?.length === this.#schemas.attributeTypes.length) {
          json.complete = true;
          json.testsTaken = [];
        }

        const assessmentUpdate = await this.#dynamoService.updateAssessment({
          assessmentID,
          typeID,
          complete: !!json.complete,
          testsTaken: json.testsTaken ?? [],
        });

        return res.success({
          dynamoRes,
          total: assessmentUpdate.json.testsTaken,
          preTotal: json.testsTaken,
          body,
          newAttributeDetail,
        });
      }
    );
  };
}

module.exports.AttributeResources = AttributeResources;
