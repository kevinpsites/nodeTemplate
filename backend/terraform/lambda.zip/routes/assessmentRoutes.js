class AssessmentResources {
  prefix = "assessments";

  #config;
  #dynamoService;
  #validatorService;
  #schemas;

  #basicFunctions;
  #tokenFunctions;
  #attributeFunctions;
  #routePermissionMiddleware;

  constructor({
    config,
    basicFunctions,
    tokenFunctions,

    attributeFunctions,

    dynamoService,
    validatorService,
    schemas,

    routePermissionMiddleware,
  }) {
    this.#config = config;
    this.#basicFunctions = basicFunctions;
    this.#tokenFunctions = tokenFunctions;

    this.#attributeFunctions = attributeFunctions;

    this.#dynamoService = dynamoService;
    this.#validatorService = validatorService;
    this.#schemas = schemas;

    this.#routePermissionMiddleware = routePermissionMiddleware;
  }

  routes = (api, opts) => {
    // get all assessments
    api.get(
      "/",
      //   verifyRoutePermissionsMiddleware("read:thoughts"),
      async (req, res) => {
        const query = req.query ?? {};
        const userID = this.#tokenFunctions.getUserID(req);

        const dynamoRes = await this.#dynamoService.queryAllUserAssessments(
          userID,
          query.nextPageKey
        );

        // const altres = await this.#dynamoService.queryAllUserAssessmentsByDate(
        //   userID,
        //   query.nextPageKey
        // );

        // const dynamoRes3 = await this.#dynamoService.queryAttributeEntries(
        //   userID,
        //   "Faith",
        //   query.nextPageKey
        // );

        return res.success(dynamoRes);
      }
    );

    // sample all assessments
    // {
    //   items:[
    //     {
    //       "typeID": "assessment#1698613317888#f9548089-30ab-94de-3612-d124d53f8c1d",
    //       "createdOn": 1698613317888,
    //       "userID": "auth0|6475234fac6ba292f88d40e6_assessment",
    //       "modifiedOn": 1698613318490,
    //       "json": {
    //           "complete": false,
    //           "testsTaken": [
    //               "virtue"
    //           ]
    //       },
    //       "assessmentID": "f9548089-30ab-94de-3612-d124d53f8c1d"
    //   },
    //   ]
    // }

    // api.get(
    //   "/date",
    //   //   verifyRoutePermissionsMiddleware("read:thoughts"),
    //   async (req, res) => {
    //     const query = req.query ?? {};
    //     const userID = this.#tokenFunctions.getUserID(req);

    //     // 1cb7c7c0-fe7a-0b83-e8e2-ff4cd2029e3d
    //     // 94e54932-17f6-b904-51a9-1f94f23cc34d
    //     // dc5b4e53-968f-9937-2d1c-391906b898b7
    //     // 7dfef106-d708-0e4f-6025-d40776b8169b

    //     console.log("PRESEARCHING");

    //     const { assessmentID, typeID, json, createdOn } =
    //       await this.#dynamoService.querySingleAssessment(
    //         userID,
    //         query.assessmentID ?? "1cb7c7c0-fe7a-0b83-e8e2-ff4cd2029e3d"
    //       );

    //     console.log("searching", createdOn);

    //     const dynamoRes =
    //       await this.#dynamoService.queryPreviousAssessmentByDate(
    //         userID,
    //         createdOn,
    //         query.nextPageKey
    //       );

    //     // const dynamoRes3 = await this.#dynamoService.queryAttributeEntries(
    //     //   userID,
    //     //   "Faith",
    //     //   query.nextPageKey
    //     // );

    //     return res.success(dynamoRes);
    //   }
    // );

    // create new assessment
    api.post(
      "/",
      //   verifyRoutePermissionsMiddleware("read:thoughts"),
      async (req, res) => {
        const userID = this.#tokenFunctions.getUserID(req);

        const body = req.body ?? {};
        const query = req.query ?? {};

        const assessmentID = this.#basicFunctions.generateRandom12ID();

        const storedDate = Date.now();

        const newAssessment = {
          typeID: `assessment#${storedDate}#${assessmentID}`,
          assessmentID,
          userID: `${userID}_assessment`,
          createdOn: storedDate,
          modifiedOn: storedDate,
          json: {
            complete: false,
            testsTaken: [],
          },
        };

        const validObj = this.#validatorService.validate(
          newAssessment,
          this.#schemas.assessmentSchema
        );
        if (!validObj.valid) {
          return res.success(
            {
              error: validObj.errors[0],
            },
            "Schema Failed"
          );
        }

        const dynamoRes = await this.#dynamoService.createAssessment(
          newAssessment
        );

        return res.success({ test: "assess", newAssessment, dynamoRes });
      }
    );

    // sample new assessment
    // {
    //   "newAssessment": {
    //     "typeID": "assessment#1697407401667#7dfef106-d708-0e4f-6025-d40776b8169b",
    //     "assessmentID": "7dfef106-d708-0e4f-6025-d40776b8169b",
    //     "userID": "auth0|6475234fac6ba292f88d40e6_assessment",
    //     "createdOn": 1697407401667,
    //     "modifiedOn": 1697407401667,
    //     "json": {
    //         "complete": false,
    //         "testsTaken": []
    //     }
    // },
    // }

    // 4bb4a4a3-a891-3177-09ef-b54e73e9dcbd
    // get specific assessment details
    api.get(
      "/:assessmentID",
      //   verifyRoutePermissionsMiddleware("read:thoughts"),
      async (req, res) => {
        const query = req.query ?? {};
        const userID = this.#tokenFunctions.getUserID(req);
        const { assessmentID: assessmentIDQ } =
          // req.pathParameters ??
          {
            assessmentID: "7dfef106-d708-0e4f-6025-d40776b8169b",
          };

        // current assessment
        const assessment = await this.#dynamoService.querySingleAssessment(
          userID,
          assessmentIDQ
        );

        // if no attributes taken return early
        if (
          !assessment.json.complete &&
          assessment.json.testsTaken.length === 0
        ) {
          return res.success({
            assessment,
            attributeDict: {},
          });
        }

        // CHECK IF CURRENT ASSESSMENT HAS DETAILS/COMPLETE ELSE SKIP
        // current assessment attribute Details
        const attributeDetails =
          await this.#dynamoService.queryAssessmentDetails(
            assessmentIDQ,
            query.nextPageKey
          );

        // previous assessment
        const previousAssessment =
          await this.#dynamoService.queryPreviousAssessmentByDate(
            userID,
            assessment.createdOn,
            assessmentIDQ
          );

        // CHECK IF PREVIOUS ASSESSMENT HAS DETAILS/COMPLETE ELSE SKIP
        // previous assessment attribute Details
        let previousAssessmentAttributes = { items: [] };
        let previousAssessmentDate = null;
        if (previousAssessment != null) {
          previousAssessmentAttributes =
            await this.#dynamoService.queryAssessmentDetails(
              previousAssessment.assessmentID,
              query.nextPageKey
            );

          previousAssessmentDate = previousAssessment.createdOn;
        }

        // Go through and compare responses/questions
        const attributeDict = this.#attributeFunctions.compareAttributes(
          attributeDetails,
          previousAssessmentAttributes,
          this.#basicFunctions.roundToXSpots
        );

        // TO-DO - do summary cards to find greatest and least improvement

        return res.success({
          assessment,
          previousAssessmentDate,
          attributeDict,
          // previous: {
          //   previousAssessment,
          //   previousAssessmentAttributes,
          // },
        });
      }
    );

    // SAMPLE ATTRIBUTE
    //   {
    //     "status": "SUCCESS",
    //     "message": "success",
    //     "moreInfo": null,
    //     "result": {
    //         "assessment": {
    //             "typeID": "assessment#1697407401667#7dfef106-d708-0e4f-6025-d40776b8169b",
    //             "createdOn": 1697407401667,
    //             "modifiedOn": 1697921909439,
    //             "userID": "auth0|6475234fac6ba292f88d40e6_assessment",
    //             "json": {
    //                 "complete": false,
    //                 "testsTaken": [
    //                     "hope"
    //                 ]
    //             },
    //             "assessmentID": "7dfef106-d708-0e4f-6025-d40776b8169b"
    //         },
    //         "previousAssessmentDate": 1697407390389,
    //         "attributeDict": {
    //             "hope": {
    //                 "type": "hope",
    //                 "date": 1697921909332,
    //                 "prevDate": 1697921971832,
    //                 "summary": {
    //                     "highest": {
    //                         "score": 0.99,
    //                         "id": "1"
    //                     },
    //                     "lowest": {
    //                         "score": 0.2,
    //                         "id": "3"
    //                     },
    //                     "total": {
    //                         "questionCount": 4,
    //                         "totalPercentage": 0.51,
    //                         "totalDiff": -0.07
    //                     }
    //                 },
    //                 "responses": [
    //                     {
    //                         "rID": "1",
    //                         "pDiff": 0.12,
    //                         "vDiff": 0,
    //                         "rawValue": 1,
    //                         "percentage": 0.99
    //                     },
    //                     {
    //                         "rID": "2",
    //                         "pDiff": -0.1,
    //                         "vDiff": 0,
    //                         "rawValue": 1,
    //                         "percentage": 0.64
    //                     },
    //                     {
    //                         "rID": "3",
    //                         "pDiff": -0.4,
    //                         "vDiff": 0,
    //                         "rawValue": 1,
    //                         "percentage": 0.2
    //                     },
    //                     {
    //                         "rID": "4",
    //                         "pDiff": 0.1,
    //                         "vDiff": 0,
    //                         "rawValue": 1,
    //                         "percentage": 0.21
    //                     }
    //                 ]
    //             }
    //         }
    //     }
    // }

    // api.get("/traits", async (req, res) => {
    //   for (let tI = 0; tI < traits.length; tI++) {
    //     const trait = traits[tI];

    //     const dynamoRes = await this.#dynamoService.createAssessment({
    //       ...trait,
    //       modifiedOn: trait.createdOn,
    //     });
    //   }
    // });

    // // update specific assessment
    // api.put(
    //   "/:assessmentID",
    //   //   verifyRoutePermissionsMiddleware("read:thoughts"),
    //   async (req, res) => {
    //     const userID = this.#tokenFunctions.getUserID(req);

    //     const { complete } = req.body ?? { complete: false };
    //     const query = req.query ?? {};

    //     const { assessmentID: assessmentIDQ } = req.pathParameters ?? {};

    //     const { assessmentID, typeID, json } =
    //       await this.#dynamoService.querySingleAssessment(
    //         userID,
    //         assessmentIDQ
    //       );

    //     const dynamoRes = await this.#dynamoService.updateAssessment({
    //       assessmentID,
    //       typeID,
    //       complete: !!complete,
    //       testsTaken: json.testsTaken ?? [],
    //     });

    //     return res.success(dynamoRes);
    //   }
    // );
  };
}

module.exports.AssessmentResources = AssessmentResources;
