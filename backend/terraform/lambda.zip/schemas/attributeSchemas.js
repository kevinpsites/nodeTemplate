const attributeTypes = [
  "prayer",
  "study",
  "faith",
  "hope",
  "charity",
  "virtue",
  "knowledge",
  "patience",
  "humility",
  "diligence",
  "obedience",
];

const attributeTypeSchema = {
  id: "/attributeType",
  type: "object",
  properties: {
    attributeType: {
      type: "string",
      enum: attributeTypes,
    },
  },
  required: ["attributeType"],
};

const highLowObj = {
  type: "object",
  properties: {
    id: { type: "string" },
    score: { type: "number" },
  },
};
const attributeDetailSchema = {
  id: "/attributeDetail",
  type: "object",
  properties: {
    typeID: { type: "string" },
    assessmentID: { type: "string" },
    userID: { type: "string" },
    createdOn: { type: "integer" },
    modifiedOn: { type: "integer" },

    json: {
      type: "object",
      properties: {
        summary: {
          type: "object",
          properties: {
            highest: highLowObj,
            lowest: highLowObj,
            total: {
              type: "object",
              properties: {
                questionCount: { type: "integer" },
                totalPercentage: { type: "number" },
              },
              additionalProperties: false,
            },
          },
          required: ["highest", "lowest", "total"],
          additionalProperties: false,
        },
      },
      required: ["summary"],
    },
  },
  required: [
    "typeID",
    "assessmentID",
    "userID",
    "createdOn",
    "modifiedOn",
    "json",
  ],
  additionalProperties: false,
};

// definition for response obj
const attributeResponseObj = {
  type: "object",
  properties: {
    qID: { type: "string" },

    rawValue: { type: "integer" },
    percentage: { type: "number" },
  },
  required: ["qID", "rawValue", "percentage"],
  additionalProperties: false,
};

// Schema for each attribute

// Prayer - 11 Q's, - 1-9 scale
// Study - 6 q's - 1-5 scale

// Faith - 9 q - 1-5 scale
// Hope - 4 q - 5 scale
// charity - 10 q - 5 sale
// virtue - 6 q - 5 sc
// knowledge - 5 q - 5 sc
// patience - 6 - 5 sc
// humilty - 6 - 5 sc
// diligence - 7 - 5 sc
// obedience - 4 - 5 sc

const prayerSchema = {
  id: "/prayer",
  type: "array",
  items: attributeResponseObj,
  minItems: 11,
  maxItems: 11,
  additionalProperties: false,
};

const studySchema = {
  id: "/study",
  items: attributeResponseObj,
  minItems: 6,
  maxItems: 6,
  additionalProperties: false,
};

const faithSchema = {
  id: "/faith",
  items: attributeResponseObj,
  minItems: 9,
  maxItems: 9,
  additionalProperties: false,
};

const hopeSchema = {
  id: "/hope",
  type: "array",
  items: attributeResponseObj,
  minItems: 4,
  maxItems: 4,
  additionalProperties: false,
};

const charitySchema = {
  id: "/charity",
  items: attributeResponseObj,
  minItems: 10,
  maxItems: 10,
  additionalProperties: false,
};

const virtueSchema = {
  id: "/virtue",
  items: attributeResponseObj,
  minItems: 6,
  maxItems: 6,
  additionalProperties: false,
};

const knowledgeSchema = {
  id: "/knowledge",
  items: attributeResponseObj,
  minItems: 5,
  maxItems: 5,
  additionalProperties: false,
};

const patienceSchema = {
  id: "/patience",
  items: attributeResponseObj,
  minItems: 6,
  maxItems: 6,
  additionalProperties: false,
};

const humilitySchema = {
  id: "/humility",
  items: attributeResponseObj,
  minItems: 6,
  maxItems: 6,
  additionalProperties: false,
};

const diligenceSchema = {
  id: "/diligence",
  items: attributeResponseObj,
  minItems: 7,
  maxItems: 7,
  additionalProperties: false,
};

const obedienceSchema = {
  id: "/obedience",
  items: attributeResponseObj,
  minItems: 4,
  maxItems: 4,
  additionalProperties: false,
};

const getAttributeSchema = (attributeType) => {
  let schema;
  switch (attributeType.toLowerCase()) {
    case "prayer":
      schema = prayerSchema;
      break;
    case "study":
      schema = studySchema;
      break;
    case "faith":
      schema = faithSchema;
      break;
    case "hope":
      schema = hopeSchema;
      break;
    case "charity":
      schema = charitySchema;
      break;
    case "virtue":
      schema = virtueSchema;
      break;
    case "knowledge":
      schema = knowledgeSchema;
      break;
    case "patience":
      schema = patienceSchema;
      break;
    case "humility":
      schema = humilitySchema;
      break;
    case "diligence":
      schema = diligenceSchema;
      break;
    case "obedience":
      schema = obedienceSchema;
      break;

    default:
      break;
  }

  return schema;
};
module.exports.attributeTypes = attributeTypes;
module.exports.schemas = {
  attributeTypeSchema,
  attributeDetailSchema,
  prayerSchema,
  studySchema,
  faithSchema,
  hopeSchema,
  charitySchema,
  virtueSchema,
  knowledgeSchema,
  patienceSchema,
  humilitySchema,
  diligenceSchema,
  obedienceSchema,
  getAttributeSchema,
};
